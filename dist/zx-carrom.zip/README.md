# Carrom Arena ZX

Carrom Arena is a ZX Spectrum 48K machine-code game in which four autonomous robot players play doubles carrom.

Upstream project: `https://github.com/tuklusan/carrom-arena`. The production build is source-first: it assembles the game and the adapted turbo-loader bootstrap with Pasmo, builds both tape formats, and rejects structural mismatches.

## Build

The normal build entry point is:

```text
python3 build.py
```

It requires:

- Python 3;
- **Pasmo** from `https://github.com/tuklusan/pasmo`, on `PATH` or selected with `PASMO=/path/to/pasmo`;
- the command-line **ZQLoader** host tool from `https://github.com/tuklusan/zqloader`, on `PATH` or selected with `ZQLOADER=/path/to/zqloader`.

Generated font, board-table, and music assets are checked in. `python3 build.py --regen-assets` regenerates them and additionally needs Pillow, NumPy, and SkoolKit from `https://github.com/tuklusan/skoolkit`.

`tools/prepare_pasmo.py` deterministically flattens the hand-maintained game sources and converts old local-label/directive conveniences into Pasmo-compatible assembly. `tools/build_zqloader_pasmo.py` does the corresponding deterministic preparation for the adapted 48K ZQLoader bootstrap; the historical loader TAP from the handoff is comparison material only and is never a production input; `dist/reference/README.md` records its hash.

The clean Ubuntu GitHub Actions build pins and compiles the Pasmo fork and ZQLoader host tool from source, runs two production builds, compares their game binary/TAP/TZX/release ZIP byte-for-byte, validates the tape structures, records SHA-256 hashes, and uploads the release artifact.

## Repository vocabulary gate

This repository includes tracked local hooks plus the same checker in the build workflow. Activate the hooks once in each clone:

```text
git config core.hooksPath .githooks
```

The local checks reject restricted vocabulary in the complete staged index and in the proposed commit message. The build workflow repeats the check against the committed tree and current commit message, so bypassing a local hook does not produce a passing build.

## Delivery rule

Accepted project deliverables are repository content, not temporary job output. Every accepted release must commit its final deliverables under `dist/` on `main`. A release is not complete until the tracked files in `dist/` match a fresh validated build. Workflow artifacts may mirror those files for convenience, but they never replace the committed copies.

## Release files

A successful build creates:

- `dist/carrom.tap` — standard ROM-speed Spectrum TAP;
- `dist/carrom_fast.tzx` — ZQLoader-based turbo TZX at exactly 2x ROM data timing.

`tools/package_release.py dist/zx-carrom.zip` makes the deterministic source-plus-release archive. No WAV release artifact is produced.

The standard tape sequence is BASIC loader, full 6912-byte loading SCREEN$, game CODE, then entry at 32768. The SCREEN$ is generated deterministically from the checked-in 4x8 font and includes the complete key legend. The TAP validator checks all six blocks, XOR checksums, SCREEN$ address/size/content, machine-code length, load address `$8000` (32768), entry point 32768, and exact equality between the CODE payload and the freshly assembled binary.

The final TZX is independently parsed and must contain:

- ROM pilot 1: **2824 pulses**;
- ROM pilot 2: **2420 pulses**;
- fast leader: **256 pulses at 1710 T-states each**;
- fast headers stored as standard TZX turbo-data blocks (`0x11`), with payloads in pure-data blocks (`0x14`);
- turbo zero pulse: **855 T-states**;
- turbo one pulse: **1710 T-states**;
- no explicit pause blocks;
- **0 ms** pause on every data block.

The release TZX uses two equal pulses per bit, so each encoded zero pulse is 855 T-states and each encoded one pulse is 1710 T-states. The loader consumes both pulses before advancing to the next bit, which leaves enough processing room without a per-byte delay. `loader/tzx19to13.py` converts the host tool's generalized blocks into compact standard turbo (`0x11`), one-pulse tone (`0x12`), and pure-data (`0x14`) blocks. Its retained legacy path still shortens a leader across a whole contiguous `0x13` stream rather than only its first chunk. The turbo edition follows the same visible sequence as the standard tape: BASIC first, then the shared SCREEN$, then game bytes, then entry at 32768. Its payloads use the loader's direct-copy path so zero-gap transitions do not depend on decompression time.

## Audio

The audio authority is `https://github.com/tuklusan/ZX-Spectrum-1-Bit-Routines`. The bundled provenance and BSD-style upstream licence are under `vendor/ZX-Spectrum-1-Bit-Routines/`.

- Title/result music uses a callable nanobeep-family player derived from the utz/irrlicht-project routines.
- Live game music uses an interrupt-safe 50 Hz phase-accumulator design so play continues while music runs.
- The live track is an original 32-bar Bollywood/EDM-inspired loop at about 125 BPM. At 512 six-frame steps it repeats after about **61.44 seconds**.
- Short game effects use the same general 1-bit synthesis family rather than the old BuzzKick/unrelated-effects mixture.

## Controls and play

The shared loading picture uses the 4x8 project font for its key legend. On machine-code entry, the load notice is replaced in place by a flashing small-font prompt. The play screen title is also rendered with the 4x8 font. During play, three independently paced star layers stream outward beside the board, with slower clustered galaxy shapes behind the faster streaks. The east field is confined to its own outer strip, with a safety gap beside the east robot, and the red/yellow/green/cyan ribbon sits at the far-right edge.

Four robot players operate autonomously; RED is North/South and BLUE is East/West.

- **SPACE** — pause/resume
- **F** — fast/normal play
- **M** — cycle sound modes (music+effects, effects only, silent)
- **R** — restart the match
- **Q** — restore normal Spectrum interrupt state and return to BASIC

## Memory map

The main program starts at `$8000`. Board pixels use `$E000-$F7FF`, board attributes `$F800-$FAFF`, the IM2 jump/vector area is `$FDFD/$FE00`, and the game stack is below `$FDF0`. The BASIC loader uses `CLEAR 32767` and starts the machine code with `RANDOMIZE USR 32768`.

## Project layout

- `src/` — game, physics, robots, rendering, generated assets, and audio source.
- `loader/` — adapted ZQLoader source, licence, and TZX finalizer.
- `tools/` — Pasmo preparation/build helpers, tape builders/validators, simulator, and deterministic packager.
- `vendor/ZX-Spectrum-1-Bit-Routines/` — upstream audio reference, provenance, and licence.
- `dist/reference/` — hashes/provenance for historical comparison tapes; never accepted release output.
- `build/` — disposable build products (untracked).
- `dist/` — accepted release outputs after a successful build.

## Verification status

Current status is emulator runtime-accepted. The clean Ubuntu workflow uses cycle-level ZX Spectrum 48K tape playback rather than instant-load shortcuts. It requires the standard TAP to reach the machine-code entry point and requires the exact release TZX to do so three times in succession with the zero-gap, short-leader format intact. The fast-tape checks also require the tape to reach its physical end before the entry point is accepted, so a loader that jumps early and then resumes reading cannot pass.

The run-time harness then exercises a deterministic live match long enough to see all four robot seats take turns, multiple strikes and pocket events, stable turn progression, a complete live-music loop, and clean screen state. It also injects and verifies all three sound modes, pause/freeze/resume, fast/normal switching, match restart, effects returning idle, and return to BASIC. A second live check starts from the fast-tape snapshot. These are emulator results only; no real-hardware claim is made.

## Credits and licences

Carrom Arena © 2026 Supratim Sanyal of SANYALnet Labs, under the SANYALnet Labs Non-Commercial License used by the original project.

The 1-bit audio work derives techniques/code from the utz/irrlicht-project `ZX-Spectrum-1-Bit-Routines` collection; see the bundled upstream licence and `PROVENANCE.md`. ZQLoader is by Daan Scherft (Oxidaan) and is retained under its MIT licence; see `loader/ZQLOADER_LICENSE.txt`.
